public class Main {
    public static void main(String[] args) {
        sinhvien a = new sinhvien();
        a.nhap();
        a.sua();
        a.in();
    }
}