public class Main {
    public static void main(String[] args) {
        thisinh a = new thisinh();
        a.in();
    }
}