public class Main {
    public static void main(String[] args) {
        giaovien a = new giaovien();
        a.doi();
        a.in();
    }
}